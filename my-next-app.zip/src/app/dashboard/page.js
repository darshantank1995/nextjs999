"use client";
import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";

export default function DashboardPage() {
  const router = useRouter();
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const raw = localStorage.getItem("auth") || sessionStorage.getItem("auth");
    if (!raw) {
      router.push("/login");
      return;
    }

    try {
      const auth = JSON.parse(raw);
      // check expiry
      if (!auth?.accessToken || Date.now() > auth.expiresAt) {
        localStorage.removeItem("auth");
        sessionStorage.removeItem("auth");
        router.push("/login");
        return;
      }
    } catch {
      router.push("/login");
      return;
    }

    setLoading(false); // ✅ user is valid
  }, [router]);

  if (loading) {
    return <div className="p-4">Checking authentication...</div>;
  }

  return (
    <div className="container py-4">
      <h1 className="mb-3">Dashboard</h1>
      <p>You are logged in 🎉</p>
    </div>
  );
}
